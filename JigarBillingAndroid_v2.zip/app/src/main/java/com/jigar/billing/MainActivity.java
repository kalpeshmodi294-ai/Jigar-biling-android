package com.jigar.billing;

import android.app.*; import android.os.*; import android.content.*; import android.graphics.*; import android.graphics.pdf.PdfDocument; import android.net.Uri; import android.view.*; import android.widget.*; import java.io.*; import java.util.*;

public class MainActivity extends Activity {
 static ArrayList<String> customers=new ArrayList<>(), products=new ArrayList<>();
 static ArrayList<Double> stock=new ArrayList<>(), sales=new ArrayList<>(), dues=new ArrayList<>();
 int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
 public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main);
  findViewById(R.id.sale).setOnClickListener(v->sale());
  findViewById(R.id.customer).setOnClickListener(v->customer());
  findViewById(R.id.product).setOnClickListener(v->product());
  findViewById(R.id.udhaar).setOnClickListener(v->udhaar());
  findViewById(R.id.report).setOnClickListener(v->report());
 }
 EditText input(String h){EditText e=new EditText(this);e.setHint(h);e.setSingleLine();return e;}
 void customer(){EditText n=input("Customer name"); EditText m=input("Mobile"); LinearLayout l=box(n,m);
  new AlertDialog.Builder(this).setTitle("Add Customer").setView(l).setPositiveButton("Save",(d,w)->{customers.add(n.getText()+" | "+m.getText());toast("Customer saved");}).setNegativeButton("Cancel",null).show();}
 void product(){EditText n=input("Product name"); EditText s=input("Opening stock");s.setInputType(2|8192);EditText r=input("Sale rate");r.setInputType(2|8192);LinearLayout l=box(n,s,r);
  new AlertDialog.Builder(this).setTitle("Add Product").setView(l).setPositiveButton("Save",(d,w)->{products.add(n.getText()+" | ₹"+r.getText());stock.add(num(s.getText().toString()));toast("Product saved");}).setNegativeButton("Cancel",null).show();}
 void sale(){if(products.size()==0){toast("Pehle Product add karein");return;} EditText c=input("Customer name / Cash");EditText q=input("Quantity");q.setInputType(2|8192);Spinner sp=new Spinner(this);sp.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,products));
  LinearLayout l=box(c,sp,q);new AlertDialog.Builder(this).setTitle("New Sale").setView(l).setPositiveButton("Create",(d,w)->{int i=sp.getSelectedItemPosition();double qty=num(q.getText().toString());double rate=parseRate(products.get(i));if(qty>stock.get(i)){toast("Stock kam hai");return;}stock.set(i,stock.get(i)-qty);double total=qty*rate;sales.add(total);String cust=c.getText().toString();if(!cust.isEmpty()&&!cust.equalsIgnoreCase("cash"))dues.add(total);pdf(cust,products.get(i),qty,rate,total);}).setNegativeButton("Cancel",null).show();}
 void udhaar(){double t=0;for(double x:dues)t+=x;new AlertDialog.Builder(this).setTitle("Udhaar / Outstanding").setMessage("Total outstanding: ₹"+String.format("%.2f",t)+"\nCustomers with credit sales: "+dues.size()).setPositiveButton("OK",null).show();}
 void report(){double t=0;for(double x:sales)t+=x;new AlertDialog.Builder(this).setTitle("Sales Report").setMessage("Invoices: "+sales.size()+"\nTotal sales: ₹"+String.format("%.2f",t)+"\nOutstanding: ₹"+String.format("%.2f",sum(dues))).setPositiveButton("OK",null).show();}
 LinearLayout box(View...v){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(12),0,dp(12),0);for(View x:v)l.addView(x);return l;}
 double num(String s){try{return Double.parseDouble(s);}catch(Exception e){return 0;}}
 double parseRate(String s){try{String x=s.substring(s.indexOf("₹")+1);return Double.parseDouble(x.trim());}catch(Exception e){return 0;}}
 double sum(ArrayList<Double>a){double t=0;for(double x:a)t+=x;return t;}
 void pdf(String c,String p,double q,double r,double total){String no="JP-"+System.currentTimeMillis();PdfDocument d=new PdfDocument();PdfDocument.Page pg=d.startPage(new PdfDocument.PageInfo.Builder(595,842,1).create());Canvas cv=pg.getCanvas();Paint pt=new Paint();pt.setTextSize(20);pt.setFakeBoldText(true);cv.drawText("Jigar Plastic & Household",40,55,pt);pt.setTextSize(12);pt.setFakeBoldText(false);cv.drawText("Invoice: "+no,40,85,pt);cv.drawText("Customer: "+(c.isEmpty()?"Cash Customer":c),40,110,pt);cv.drawText("Product: "+p,40,145,pt);cv.drawText("Qty: "+q+"   Rate: ₹"+r,40,170,pt);pt.setFakeBoldText(true);cv.drawText("Grand Total: ₹"+String.format("%.2f",total),40,215,pt);d.finishPage(pg);try{File f=new File(getExternalFilesDir(null),"Invoice-"+no+".pdf");d.writeTo(new FileOutputStream(f));d.close();Intent s=new Intent(Intent.ACTION_SEND);s.setType("application/pdf");s.putExtra(Intent.EXTRA_STREAM,Uri.fromFile(f));startActivity(Intent.createChooser(s,"Share Invoice"));}catch(Exception e){d.close();toast("PDF error");}}
 void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
